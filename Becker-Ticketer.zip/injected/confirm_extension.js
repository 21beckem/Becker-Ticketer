const BECKERTICKETEREXTENSIONISINSTALLED = true;
if (typeof confirmBeckerTicketerIsInstalled === 'function') {
    confirmBeckerTicketerIsInstalled();
}